# پشمک استور V6.2.0 FINAL

این نسخه شامل موجودی اولیه دستی/JSON، مدیریت شیفت، انتقال امن بین دو گوشی و ثبت فروش جاافتاده است.

Package ID: `com.pashmak.store.v620final`
Version Code: `620`
Version Name: `6.2.0-final`
